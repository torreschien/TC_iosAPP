//
//  FemaleCelebrity.swift
//  Demo2
//
//  Created by Peter Pan on 2023/5/5.
//

import Foundation

struct FemaleCelebrity {
    let name: String
    let intro: String
    let height: Int 
}
