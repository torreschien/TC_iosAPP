//
//  ViewController.swift
//  Demo2
//
//  Created by Peter Pan on 2023/5/5.
//

import UIKit



class ViewController: UIViewController {

    @IBOutlet weak var introLabel: UILabel!
    @IBOutlet weak var imageView: UIImageView!
    var index = 0
    let femaleCelebrities = [
        FemaleCelebrity(name: "Lisa", intro: "來自韓國女子團體 BLACKPINK 的才華橫溢歌手與舞者。", height: 166),
        FemaleCelebrity(name: "IU", intro: "廣受歡迎的韓國創作歌手和演員。", height: 160),
        FemaleCelebrity(name: "Emma Watson", intro: "英國女演員兼社會活動家，因在哈利波特系列中飾演赫敏而聞名。", height: 165),
        FemaleCelebrity(name: "Scarlett Johansson", intro: "美國女演員兼歌手，因在漫威電影宇宙中飾演黑寡婦而聞名。", height: 160),
        FemaleCelebrity(name: "Natalie Portman", intro: "擁有以色列和美國國籍的演員和電影製片人，因在星際大戰前傳三部曲中飾演帕美·阿米達拉而聞名。", height: 160)
    ]

    
    
    fileprivate func updateUI() {
        // Do any additional setup after loading the view.
        let femaleCelebrity = femaleCelebrities[index]
        imageView.image = UIImage(named: femaleCelebrity.name)
        introLabel.text = femaleCelebrity.intro
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        updateUI()
    }

    @IBAction func next(_ sender: Any) {
        index = (index + 1) % femaleCelebrities.count
        updateUI()

    }
    
}

