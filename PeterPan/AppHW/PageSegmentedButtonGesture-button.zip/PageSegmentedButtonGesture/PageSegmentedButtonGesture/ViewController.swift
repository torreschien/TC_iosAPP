//
//  ViewController.swift
//  PageSegmentedButtonGesture
//
//  Created by TorresChien on 2023/5/8.
//

import UIKit

class ViewController: UIViewController, UIScrollViewDelegate {
    
    // MARK: - IBO
    @IBOutlet weak var albumScrollView: UIScrollView!
    @IBOutlet weak var albumPageControl: UIPageControl!
    @IBOutlet weak var albumSegmentedControl: UISegmentedControl!
    
    @IBOutlet weak var view01: UIView!
    @IBOutlet weak var view02: UIView!
    @IBOutlet weak var view03: UIView!
    
    @IBOutlet weak var previousButton: UIButton!
    @IBOutlet weak var nextButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // 將 app 設置為固定 dark mode
        overrideUserInterfaceStyle = .dark
        // 將 previous 一開始設置為隱藏
        previousButton.isHidden = true
    }
    // MARK: - 判斷目前頁面並更新小圓點
    func scrollViewDidEndDecelerating(_ scrollView: UIScrollView) {
        let page = albumScrollView.contentOffset.x / albumScrollView.bounds.width
        albumPageControl.currentPage = Int(page)
        albumSegmentedControl.selectedSegmentIndex = Int(page)
        showView(at: Int(page))
        buttonHiddenOrNot(at: Int(page))
        
    }

    // MARK: - 小圓點的 Action
    @IBAction func albumPageControl(_ sender: UIPageControl) {
        let point = CGPoint(
            x: albumScrollView.bounds.width * CGFloat(sender.currentPage),
            y: 0)
        albumScrollView.setContentOffset(point, animated: true)
        albumSegmentedControl.selectedSegmentIndex = sender.currentPage
        
        showView(at: sender.currentPage)
        buttonHiddenOrNot(at: sender.currentPage)
        
        
    }
    // MARK: - Action
    // Segmented Control 的動作
    @IBAction func albumSegmentedControlValueChange(_ sender: UISegmentedControl) {
        // 取得選擇的選項索引
        let index = sender.selectedSegmentIndex
        // 設置 UIScrollView 的 contentOffset 為對應的位置
        let point = CGPoint(
            x: view.bounds.width * CGFloat(index),
            y: 0)
        albumScrollView.setContentOffset(point, animated: true)
        // 更新 pagecontrol 的當前頁面
        albumPageControl.currentPage = index
        showView(at: index)
        buttonHiddenOrNot(at: index)
    }
    // Previous Button 的動作
    @IBAction func previousButtonChangePage(_ sender: UIButton) {
        let currentPage = albumPageControl.currentPage
        if currentPage > 0 {
            let point = CGPoint(
                x: albumScrollView.bounds.width * CGFloat(currentPage - 1),
                y: 0)
            albumScrollView.setContentOffset(point, animated: true)
            albumPageControl.currentPage = currentPage - 1
            albumSegmentedControl.selectedSegmentIndex = currentPage - 1
            showView(at: currentPage - 1)
        }
    }
    // Next Button 的動作
    @IBAction func nextButtonChangePage(_ sender: UIButton) {
        let currentPage = albumPageControl.currentPage
        if currentPage < albumPageControl.numberOfPages - 1 {
            let point = CGPoint(
                x: albumScrollView.bounds.width * CGFloat(currentPage + 1),
                y: 0)
            albumScrollView.setContentOffset(point, animated: true)
            albumPageControl.currentPage = currentPage + 1
            albumSegmentedControl.selectedSegmentIndex = currentPage + 1
            showView(at: currentPage + 1)
        }
    }
    // MARK: - 顯示或隱藏
    // view 的隱藏跟顯示
    func showView(at index: Int) {
        view01.isHidden = index != 0
        view02.isHidden = index != 1
        view03.isHidden = index != 2
    }
    // button 的隱藏跟顯示
    func buttonHiddenOrNot(at index: Int) {
        previousButton.isHidden = index == 0
        nextButton.isHidden = index == albumPageControl.numberOfPages - 1
    }
}

